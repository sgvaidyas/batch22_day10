﻿using System;
namespace SinglyLinkedlist
{
    class Program
    {
        static void Main(string[] args)
        {
            Single ob = new Single();
            int ch, ele,pos;

            do
            {
                Console.WriteLine("1 Insert in the beginning");
                Console.WriteLine("2 Insert in the end");
                Console.WriteLine("3 Insert at  a given pos");
                Console.WriteLine("7 Display");
                Console.WriteLine("8 Exit");
                ch = int.Parse(Console.ReadLine());

                switch (ch)
                {
                    case 1: Console.WriteLine("Enter the element ");
                        ele = int.Parse(Console.ReadLine());
                        ob.insertbegin(ele);
                        break;
                    case 2:
                        Console.WriteLine("Enter the element ");
                        ele = int.Parse(Console.ReadLine());
                        ob.insertend(ele);
                        break;
                    case 3:
                        Console.WriteLine("Enter the element ");
                        ele = int.Parse(Console.ReadLine());

                        do
                        {
                            Console.WriteLine("Enter position");
                            pos = int.Parse(Console.ReadLine());
                        } while (pos<1 ||  pos>ob.count+1);

                        ob.insertpos(ele,pos);
                        break;
                    case 7: ob.display();
                        break;
                    case 8: break;
                    default: Console.WriteLine("invalid choice"); break;
                }
            } while (ch!=8);

        }
    }
}
