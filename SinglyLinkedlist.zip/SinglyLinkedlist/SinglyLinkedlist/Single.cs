﻿using System;

namespace SinglyLinkedlist
{
    class Node
    {
        public int data;
        public Node nextadd;
    };
    class Single
    {
        public Node head;
        public int count;

        public Single()
        {
            head = null;
            count = 0;
        }
        public Node createnode(int ele)
        {
            Node temp = new Node();
            temp.data = ele;
            temp.nextadd = null;
            count++;
            return temp;
        }
        public void insertbegin(int ele)
        {
            Node newnode = createnode(ele);
            newnode.nextadd = head;
            head = newnode;
        }


        public void insertend(int ele)
        {
            Node newnode =  createnode(ele) ;
            if (head == null)
                head = newnode;
            else
            {
                Node temp = head;
                while (temp.nextadd != null)
                    temp = temp.nextadd;

                temp.nextadd = newnode;
            }
        }
        public void insertpos(int ele,int pos)
        {
            if (pos == 1)
                insertbegin(ele);
            else if (pos == count + 1)
                insertend(ele);
            else
            {
                Node newnode = createnode(ele);
                Node pn, cn;
                pn = cn = head;
                for(int i=1;i<pos;i++)
                {
                    pn = cn;
                    cn = cn.nextadd;
                }
                pn.nextadd = newnode;
                newnode.nextadd = cn;
            }
        }


        public void display()
        {
            if(head==null)
                Console.WriteLine("No elements in the list");
            else
            {
                Console.WriteLine("\nElements of list are :");
                Node temp;
                temp = head;
                while(temp!=null)
                {
                    Console.Write(temp.data + "  \t");
                    temp = temp.nextadd;
                }
                Console.WriteLine();
            }
        }
    }
}
